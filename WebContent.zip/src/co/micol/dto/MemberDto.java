package co.micol.dto;

public class MemberDto {
	private String mId;
	private String mPassword;
	private String mName;
	private String mAddress;
	private String mGrant;
	
	public String getmGrant() {
		return mGrant;
	}


	public void setmGrant(String mGrant) {
		this.mGrant = mGrant;
	}


	public MemberDto() {
		
	}


	public String getmId() {
		return mId;
	}


	public void setmId(String mId) {
		this.mId = mId;
	}


	public String getmPassword() {
		return mPassword;
	}


	public void setmPassword(String mPassword) {
		this.mPassword = mPassword;
	}


	public String getmName() {
		return mName;
	}


	public void setmName(String mName) {
		this.mName = mName;
	}


	public String getmAddress() {
		return mAddress;
	}


	public void setmAddress(String mAddress) {
		this.mAddress = mAddress;
	}

}
