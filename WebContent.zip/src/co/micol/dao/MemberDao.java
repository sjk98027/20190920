package co.micol.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import co.micol.dto.MemberDto;

public class MemberDao extends Dao {
	private PreparedStatement psmt;
	private ResultSet rs;

	public MemberDao() {
		super();
	}

	public MemberDto loginCheck(MemberDto dto) {
		String sql = "select * from member where mid = ? and mpassword = ?";
		
		try {

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getmId());
			psmt.setString(2, dto.getmPassword());
			rs = psmt.executeQuery();
			if (rs.next()) {
				dto.setmGrant(rs.getString("mgrant"));
				
				return dto;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dto;
	}

	public int insertMember(MemberDto dto) {
		String sql = "insert into member(mid,mname,mpassword,maddress) values(?,?,?,?)";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getmId());
			psmt.setString(2, dto.getmName());
			psmt.setString(3, dto.getmPassword());
			psmt.setString(4, dto.getmAddress());

			int result = psmt.executeUpdate();
			if (result > 0) {
				return result;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}

	public boolean isIdCheck(String str) {
		boolean chk = true;
		String sql = "select * from member where mid = ?";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, str);
			rs = psmt.executeQuery();
			if (rs.next()) {
				chk = false;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return chk;
	}
}
